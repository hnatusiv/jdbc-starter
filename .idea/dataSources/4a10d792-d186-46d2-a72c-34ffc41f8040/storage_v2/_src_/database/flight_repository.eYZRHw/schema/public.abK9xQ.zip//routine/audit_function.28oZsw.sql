create function audit_function() returns trigger
    language plpgsql
as
$$
begin
    insert into audid(id, table_name, date)
    VALUES (new.id, tg_name, now());
    return null;
end;
$$;

alter function audit_function() owner to postgres;

