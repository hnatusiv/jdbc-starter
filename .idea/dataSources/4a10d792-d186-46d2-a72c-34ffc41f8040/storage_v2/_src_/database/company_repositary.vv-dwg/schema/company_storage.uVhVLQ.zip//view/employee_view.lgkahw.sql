create view employee_view (name, last_name, salary, lag, ss, count, max, maxcom, min, avg, sum, rw, row_number, rank) as
SELECT c.name,
       e.last_name,
       e.salary,
       lag(e.salary) OVER (ORDER BY e.salary)                        AS lag,
       lag(e.salary) OVER (ORDER BY e.salary) - e.salary             AS ss,
       count(*) OVER ()                                              AS count,
       max(e.salary) OVER ()                                         AS max,
       max(e.salary) OVER (PARTITION BY c.id)                        AS maxcom,
       min(e.salary) OVER ()                                         AS min,
       avg(e.salary) OVER (PARTITION BY c.id)                        AS avg,
       sum(e.salary) OVER ()                                         AS sum,
       row_number() OVER ()                                          AS rw,
       row_number() OVER (PARTITION BY c.id)                         AS row_number,
       rank() OVER (PARTITION BY c.id ORDER BY e.salary NULLS FIRST) AS rank
FROM company_storage.company c
         LEFT JOIN company_storage.employee e ON c.id = e.company_id
ORDER BY c.name;

alter table employee_view
    owner to postgres;

