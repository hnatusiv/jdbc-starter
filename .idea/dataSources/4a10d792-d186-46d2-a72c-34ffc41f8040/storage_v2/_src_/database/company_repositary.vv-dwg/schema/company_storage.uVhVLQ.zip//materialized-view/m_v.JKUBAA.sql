create materialized view m_v as
SELECT c.name,
       e.last_name,
       e.salary,
       lag(e.salary) OVER (ORDER BY e.salary)                        AS lag,
       lag(e.salary) OVER (ORDER BY e.salary) - e.salary             AS ss,
       count(*) OVER ()                                              AS count,
       max(e.salary) OVER ()                                         AS max,
       max(e.salary) OVER (PARTITION BY c.id)                        AS maxcom,
       min(e.salary) OVER ()                                         AS min,
       avg(e.salary) OVER (PARTITION BY c.id)                        AS avg,
       sum(e.salary) OVER ()                                         AS sum,
       row_number() OVER ()                                          AS rw,
       row_number() OVER (PARTITION BY c.id)                         AS row_number,
       rank() OVER (PARTITION BY c.id ORDER BY e.salary NULLS FIRST) AS rank
FROM company_storage.company c
         LEFT JOIN company_storage.employee e ON c.id = e.company_id
ORDER BY c.name;

alter materialized view m_v owner to postgres;

